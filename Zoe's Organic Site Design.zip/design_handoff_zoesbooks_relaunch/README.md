# Handoff: zoesbooks.com relaunch — full site design

## Overview

High-fidelity design for the five-page relaunch of **zoesbooks.com**, the site for
*Power-Up Your Mind: Growth Mindset Strategies and Activities for Tweens* by Zoe Roberts.

The site's primary job is **building an email list**. Amazon purchase links are the secondary
action. The reader is a 10-year-old; the buyer and subscriber is a parent, teacher, or school
counselor. Every design decision here sells to the adult.

This design implements the relaunch spec at
`docs/superpowers/specs/2026-07-24-zoesbooks-relaunch-design.md` in the existing
`zoe-roberts-writes` repo, with one deliberate deviation, described under **Deviation from the
spec** below.

## About the design files

`Zoe Roberts Site.dc.html` in this bundle is a **design reference created in HTML** — a working
prototype showing intended look and behavior. It is not production code to copy.

The target codebase already exists: a Vite + React + TypeScript + Tailwind + shadcn SPA with
`react-router`, `framer-motion`, and `i18next` already wired. The task is to **recreate this
design in that codebase**, using its existing patterns:

- Pages under `src/pages/`, one per route
- Shared pieces under `src/components/`
- All copy read from `src/content/{book,about,reviews,site}.ts` — **no content literals in
  components** (the prototype inlines its content only because it is a single file)
- Forms through the existing `useFormPost` hook
- Tailwind theme tokens in `tailwind.config.ts`, shadcn HSL custom properties in `src/index.css`

The prototype is a single file with client-side page switching. In the real app that is
`react-router` routes, not local state.

## Fidelity

**High-fidelity.** Colors, typography, spacing, radii, shadows, copy and interaction states are
final and should be matched closely. Everything is expressed in CSS custom properties from the
Organic design system (`design-system/styles.css`, included in this bundle) — port those to
`tailwind.config.ts` rather than hard-coding hex values in components.

## Deviation from the spec

The spec's Design System section specifies an ink `#16324F` / sunshine `#FFC72C` / Nunito palette.
**This design uses the Organic design system instead** — cream ground, terracotta accent, sage
second accent, Caprasimo display over Figtree — tuned toward quiet authority rather than play.
Zoe chose this direction after the spec was written. It supersedes the spec's color and typography
tables; everything else in the spec still stands.

## Content integrity — non-negotiable

The spec's **Content Integrity — Mandatory Removals** section applies in full. Nothing outstanding
is invented anywhere in this design:

| Outstanding item | How the design handles it |
|---|---|
| Author portrait | **No portrait rendered.** The About page uses a sage quote card and an "In short" fact list in its place. Do not substitute stock or AI imagery. |
| Real Amazon reviews | **No reviews section exists** on any page. Build it only when `reviews.ts` is non-empty, and hide it while empty. |
| Paperback ASIN | **Only the Kindle button renders.** When the ASIN arrives, `availableEditions()` returns two and the buttons become siblings. |
| Contact email | **Not shown anywhere.** No `mailto:`, no address block. |
| Social URLs | **No social icons anywhere**, including the footer. |
| Kit / Formspree IDs | The prototype simulates success. In the app, follow the spec: success only on 2xx, real error message plus `mailto:` fallback, submit disabled with a visible config error when the ID is missing. Never a success toast on a discarded submission. |

## Routes

| Route | Job |
|---|---|
| `/` | Hook + email capture above the fold, audience cards, book, Zoe teaser, mindset quiz |
| `/free-guide` | The point of the site — journal offer, form, page-one preview, quiz |
| `/book` | Full description, highlights, Kindle button, journal cross-sell |
| `/about` | Real bio verbatim, quote card, fact list, contact CTA |
| `/contact` | Working Formspree form |

`/books` → `/book` and `/events` → `/free-guide` as redirects, per the spec.

## Design tokens

From the Organic design system. Full source in `design-system/styles.css` — port the `:root` block
into `tailwind.config.ts` and the shadcn HSL properties in `src/index.css`.

### Color

| Token | Hex | Use in this design |
|---|---|---|
| `--color-bg` | `#f5ead8` | Page ground |
| `--color-text` | `#201e1d` | Body and headings |
| `--color-neutral-100` | `#f9f4ed` | Alternating section band, form card fills, quiz option fills |
| `--color-neutral-200` | `#eee7db` | Meta tag fills |
| `--color-neutral-300` | `#dcd3c4` | Quiz progress track; footer body text |
| `--color-neutral-400` | `#c0b6a5` | Input borders, quiz option borders, journal panel borders |
| `--color-neutral-500` | `#a19786` | Footer section labels, footer copyright |
| `--color-neutral-700` | `#645c50` | Fine print, "take it again" link |
| `--color-neutral-800` | `#474238` | Secondary body copy; footer top border |
| `--color-neutral-900` | `#2e2b25` | Footer background |
| `--color-accent-100` | `#fff2eb` | Quiz option hover fill |
| `--color-accent-200` | `#ffe1d0` | "Try it before you buy it" and "Invite Zoe" card fills |
| `--color-accent-300` | `#ffc6a5` | Those cards' borders; audience-card dot; dark-ground links |
| `--color-accent-400` | `#f6a06b` | Quiz option hover border |
| `--color-accent-500` | `#d67f48` | Active nav underline; journal prompt bullets |
| `--color-accent`/`-500` | `#c67139` | `.btn-primary` fill (from the system's `.btn-primary`) |
| `--color-accent-600` | `#b2622d` | Primary button hover |
| `--color-accent-700` | `#8c491a` | Body-size accent text, links, active nav label, `“I can’t”` in the H1 |
| `--color-accent-900` | `#402310` | Text on accent-200 fills |
| `--color-accent-2-200` | `#e1eecc` | Success states; quiz email patch; text on the dark sage band |
| `--color-accent-2-300` | `#ccdbb2` | Hero backdrop circle; dark-band eyebrow |
| `--color-accent-2-400` | `#aebf92` | Success-state borders |
| `--color-accent-2-500` | `#8fa073` | Quiz progress fill; highlight bullets |
| `--color-accent-2-700` | `#56633f` | All section eyebrows/kickers; the About quote circle |
| `--color-accent-2-800` | `#3d472b` | The dark "From Zoe" band; the About quote card; text on sage tints |

Body copy in the accent must use `--color-accent-700` or deeper — the base accent is only 3:1
against the ground.

### Typography

- Display / headings: **Caprasimo 400** (`--font-heading`) — the only display voice
- Body: **Figtree 400/600/700** (`--font-body`)
- Base body size **17px / 1.6**; secondary body 16px; fine print 14px

| Element | Size | Notes |
|---|---|---|
| Home H1 | `clamp(38px, 5.4vw, 60px)` | line-height 1.04, letter-spacing −.02em, `max-width:14ch` |
| Page H1 (Book, Guide, Contact) | `clamp(34px, 4.8vw, 54px)` | line-height 1.05–1.06 |
| About H1 | `clamp(36px, 5vw, 58px)` | |
| Section H2 | `clamp(28px, 3.6vw, 40px)` | letter-spacing −.015em |
| Card / aside H3 | 22–28px | |
| Quiz question | `clamp(22px, 2.6vw, 28px)` | Caprasimo, `max-width:34ch` |
| Pull quote (dark band) | `clamp(24px, 3vw, 34px)` | Caprasimo, line-height 1.28 |
| Eyebrow / kicker | 13px | weight 700, `letter-spacing:.12em`, uppercase, sage-700 |
| Lead paragraph | 19–20px | line-height 1.55, `max-width:46–48ch` |

`text-wrap: pretty` on every multi-line paragraph and heading.

### Spacing, radius, elevation

- Content container: `max-width: 1120px`, `padding: 0 24px`
- Vertical section rhythm: `clamp(48px, 6–7vw, 88–96px)`
- Grid gaps: `clamp(36px, 5vw, 72px)` between hero columns, 24px between cards
- Radii: `--radius-md` 16px (inputs, panels, list rows), `--radius-lg` 28px (cards, bands,
  form containers), `999px` (buttons, pills, tags, email inputs, progress bars)
- Shadows: `--shadow-sm` on the quiz card, `--shadow-md` on the secondary cover, `--shadow-lg`
  on the hero and Book-page covers. No ad-hoc shadows.

### Responsive strategy

**No media queries.** Everything is fluid: `clamp()` type and padding, and
`grid-template-columns: repeat(auto-fit, minmax(280–320px, 1fr))` on every multi-column block, so
each collapses to one column on its own. The header nav wraps with `flex-wrap`. Verify at 375,
768 and 1440px per the spec. In Tailwind this maps to `grid-cols-[repeat(auto-fit,minmax(320px,1fr))]`
and arbitrary `clamp()` values — reproduce the fluid behavior, don't convert it to breakpoints.

## Screens

### Header (all pages)

Sticky, `top:0`, `z-index:20`, background `color-mix(in srgb, var(--color-bg) 92%, transparent)`
with `backdrop-filter: blur(10px)` and a 1px `--color-divider` bottom border. Inside the 1120px
container, `padding:14px 24px`, flex, `flex-wrap:wrap`, `gap:16px 28px`.

- **Brand** (left): the ZR monogram (`assets/zr-monogram.png`, black, transparent PNG) at
  `height:30px; width:auto`, then the wordmark "Zoe Roberts" in Caprasimo 20px. Whole thing is a
  button/link to `/`.
- **Nav** (`margin-left:auto`): Home · The book · Free journal · About · Contact. Figtree 15px/600,
  `padding:6px 0`, 2px bottom border. Active route: label `--color-accent-700`, border
  `--color-accent-500`. Inactive: label `--color-text`, border transparent, hover to
  `--color-accent-700`.
- **CTA**: pill primary button "Free journal" → `/free-guide`, `padding:10px 20px`, 15px.

### Footer (all pages)

Background `--color-neutral-900`, text `--color-neutral-300`, `margin-top: clamp(40px,6vw,80px)`,
`padding: clamp(48px,6vw,72px) 24px clamp(28px,3vw,40px)`. Three-column
`repeat(auto-fit, minmax(260px,1fr))`, gap 40px:

1. "Zoe Roberts" in Caprasimo 26px `--color-neutral-100` + the tagline "Growth mindset books for
   tweens and teens."
2. **Pages** label + the same five nav links, stacked, hover `--color-accent-300`
3. **The free journal** label + "Three printable pages, sent straight to your inbox." + a pill
   primary "Get it free"

Bottom rule: 1px `--color-neutral-800`, 24px above `© 2026 Zoe Roberts · zoesbooks.com` at 14px
`--color-neutral-500`. **No social icons** until real URLs exist.

### 1. Home — `/`

**Hero.** Two fluid columns, `align-items:center`.

*Left:* eyebrow "Growth mindset books for tweens" → H1 "Teach a child that *“I can’t”* only means
“not yet.”" (the quoted phrase is an `<em>`, `font-style:normal`, `--color-accent-700`) → 20px lead
"Zoe Roberts writes for the eight-to-twelve-year-olds who have already decided what they are bad
at. Start with the free daily journal — three printable pages you can sit down and fill in
together." → inline email form → fine print "Three printable pages. No spam, unsubscribe in one
click."

*Email form:* flex, wrap, gap 10px, `max-width:520px`. Input `flex:1 1 240px`, `padding:14px 20px`,
`border-radius:999px`, 1px `--color-neutral-400`, fill `--color-neutral-100`, placeholder "Your
email address". Submit: pill primary "Send me the journal", `padding:14px 26px`, 16px.

*Success state* replaces the form: `--color-accent-2-200` fill, `--color-accent-2-400` border,
`--radius-lg`, `padding:20px 24px`, "Check your inbox." (700) + "Confirm your address and the
journal lands straight after." Fades in — see **Motion**.

*Right:* a single-cell CSS grid stacking two things: a `--color-accent-2-300` circle at
`min(100%,400px)`, `aspect-ratio:1`, `opacity:.6`, `z-index:-1` on an `isolation:isolate` parent;
and the book cover at `min(100%,320px)`, `--radius-md`, `--shadow-lg`, `transform:rotate(-2deg)`.
The cover is **not** washed — it is a product image, not a photograph.

**Audience band.** `--color-neutral-100`, divider borders top and bottom. H2 "Written for the
grown-up holding the book", 18px sub "The reader is ten. The person deciding is you.", then three
cards (`repeat(auto-fit, minmax(260px,1fr))`, gap 24px): page-ground fill, divider border,
`--radius-lg`, `padding:32px 30px`, a 34px `--color-accent-300` circle, H3 22px, 16px body.

- **Parents** — "For the kid who says “I’m just bad at maths” and means it. Short exercises you can do together at the kitchen table."
- **Teachers** — "Activity pages that work as a warm-up, a quiet-time task, or a whole lesson on effort and feedback."
- **Counselors** — "Plain-language framing of fixed and growth mindset that a nine-year-old can talk about without feeling diagnosed."

**Book section.** Two columns. Left: eyebrow "The book", H2 "Power-Up Your Mind", 20px subtitle,
an 18px paragraph, three pill tags (Ages 8–12 · 2025 · Children's self-development;
`--color-neutral-200` fill, divider border, `padding:6px 14px`), then a pill primary linking to
`https://www.amazon.com/dp/B0FG1YLHSC` (`target="_blank" rel="noopener"`) beside a text link "Read
what's inside" → `/book`. Right: cover at `min(100%,300px)`, `--shadow-md`.

**"From Zoe" band.** Full-bleed `--color-accent-2-800`, text `--color-neutral-100`. Two columns.
Left: eyebrow "From Zoe" in `--color-accent-2-300`, a Caprasimo pull quote "“Our potential is
limitless. We just need to be guided by hope and determination.”", the `BIO_TEASER` paragraph in
`--color-accent-2-200`, and an underlined link "Read Zoe's story" in `--color-accent-300`. Right:
a `--color-accent-2-700` circle, `min(100%,300px)`, `aspect-ratio:1`, `padding:40px`, holding
centered Caprasimo 22px "Washington, D.C. suburbs · business leadership · a lifelong habit of
learning".

**Quiz section.** H2 "Where does your child sit right now?", 18px sub "Five questions, two minutes.
Answer as yourself, or sit down and go through it together.", then the quiz component. Toggleable
— see **Configuration**.

### 2. Free guide — `/free-guide`

Two columns, `align-items:start`.

*Left:* eyebrow "Free · three printable pages" → H1 "My Daily Journal" → 19px lead "A one-page
daily routine your child can actually finish. Print it, stick it on the fridge, and let them fill
it in before bed." → a six-item list (10px `--color-accent-500` bullet dots, 14px gap, 17px text):

1. A daily power-level meter — how full is the tank today?
2. One thing to be grateful for
3. An affirmation in their own words
4. Today's goals, small enough to finish
5. What felt hard, and what they learned from it
6. Who they helped

Then the sign-up card: `--color-neutral-100`, divider border, `--radius-lg`, `padding:28px`,
`max-width:540px`. Label "Where should we send it?" (17px/700), pill input + pill primary "Send the
journal", fine print "You'll get a confirmation email first — that's how we keep the list clean.
Unsubscribe any time."

*Success state* replaces the card: sage-200 fill, sage-400 border, H3 "One more click" + "We've
sent a confirmation email. Open it, confirm, and the journal arrives right after."

*Right:* "Page one, at a glance" — a 2-column grid of six panels mimicking the journal's layout.
Each: 2px `--color-neutral-400` border, `--radius-md`, `padding:18px 16px`, `min-height:96px`,
page-ground fill, Caprasimo 15px label. Panels: My power level today / I am grateful for… / My
affirmation / What are my goals for today? / What did I learn? / Who did I help? Caption below:
"US Letter · black and white · print as many as you like."

*Quiz band:* `--color-neutral-100` with a divider top border. H2 "Not sure where to start?", sub
"Take the five-question mindset check first. It tells you which parts of the journal to lean on.",
then the quiz.

Note: the site does not host the PDF — Kit's automation attaches it. The supplied file still has
the three artwork defects listed in the spec and prints `WWW.ZOESBOOKS.NET`; do not link it.

### 3. Book — `/book`

Two columns, `align-items:start`.

*Left (sticky, `top:96px`):* cover at `max-width:340px`, `--radius-lg` shadow; below it a
full-width pill primary "Buy the Kindle edition" → `https://www.amazon.com/dp/B0FG1YLHSC`; below
that 14px fine print "Opens on Amazon. ASIN B0FG1YLHSC." When the paperback ASIN lands, render
both editions as sibling buttons from `availableEditions()`.

*Right:* eyebrow "Ages 8–12 · 2025", H1 "Power-Up Your Mind", 21px subtitle, then the three
`BOOK.description` paragraphs at 18px/1.65, `max-width:60ch`. Then H2 "Inside this book" and the
five `BOOK.highlights` as cards: `--color-neutral-100`, divider border, `--radius-md`,
`padding:18px 20px`, 12px sage-500 bullet, 16px gap, `max-width:62ch`.

Closing cross-sell card: `--color-accent-200` fill, `--color-accent-300` border, `--radius-lg`,
`padding:32px`. H3 "Try it before you buy it" + "The free daily journal uses the same routine as
the book's activity pages." + pill primary "Get the free journal" → `/free-guide`.

### 4. About — `/about`

Header block (`max-width:22ch`): eyebrow "About the author" + H1 "Zoe Roberts".

Two columns. *Left:* the five `BIO` paragraphs at 18px/1.7, `max-width:58ch`. **Render Zoe's
wording verbatim from `about.ts`.** One editorial fix is already applied in this design and should
be carried into `about.ts` only with Zoe's approval: the supplied fragment "When Zoe became a young
widow and an instant single mother. She poured her energy into…" is joined into one sentence
("…single mother, she poured her energy into…").

*Right aside* (stacked, gap 24px):

1. Quote card — `--color-accent-2-800`, `--color-neutral-100` text, `--radius-lg`,
   `padding:36px 32px`, Caprasimo 24px/1.3: "“Like her son, Zoe wants every child to reach for the
   stars, no matter the obstacles they face.”"
2. "In short" card — `--color-neutral-100`, divider border, 8px accent-500 bullets, 16px text:
   born and raised in the suburbs of the Nation's Capital · a background in business leadership and
   people development · widowed young, and an instant single mother · writes on well-being,
   resilience and multicultural themes · nature walks, travel, and time with family
3. "Invite Zoe" card — `--color-accent-200` / `--color-accent-300`, "School visits, classroom
   sessions, media and speaking." + pill primary "Get in touch" → `/contact`

**No portrait.** When Zoe supplies one, it goes above the bio at `--radius-lg` wrapped in the
system's `.washed` class (it is a photograph, unlike the cover).

### 5. Contact — `/contact`

Two columns. *Left:* eyebrow "Contact", H1 "Say hello", 18px lead "Zoe reads everything that comes
through this form and answers personally, usually within a few days.", then three reason blocks
(H3 19px + 16px body, gap 18px):

- **School and classroom visits** — "In person or over video, for years three through six."
- **Media and interviews** — "Growth mindset, post-traumatic growth, writing for tweens."
- **Speaking** — "Parent evenings, staff training, and community groups."

*Right:* the form card — `--color-neutral-100`, divider border, `--radius-lg`,
`padding: clamp(24px,3vw,36px)`, `display:grid; gap:18px`. Fields, each label 15px/700 with an 8px
gap: **Your name** (text, required) · **Email** (email, required) · **What's this about?**
(select: A school or classroom visit / Media or an interview / Speaking / A note about the book /
Something else) · **Message** (textarea, 5 rows, required, `resize:vertical`). Inputs:
`padding:13px 18px`, `--radius-md`, 1px `--color-neutral-400`, page-ground fill, 16px. Submit: pill
primary "Send message", `justify-self:start`.

*Success state* replaces the card: sage-200 / sage-400, H2 "Message sent" + "Thank you — Zoe will
get back to you personally." + an underlined "Send another" that resets the form.

**No contact email is shown.** When Zoe confirms one, it becomes the `mailto:` fallback on the
failure path, per the spec.

## The mindset quiz

Appears on `/` and `/free-guide`. In the real app this is one component, `MindsetQuiz`, mounted
twice — the prototype duplicates its markup only because it is a single file. The existing
`src/components/MindsetQuiz.tsx` already has this logic; restyle it and swap in the copy below.

Container: page-ground fill, divider border, `--radius-lg`, `--shadow-sm`,
`padding: clamp(28px,4vw,48px)`, `max-width:760px`.

**Idle.** H3 "Fixed or growth — a five-question check" + "There's no score to be ashamed of. Most
children come out mixed, and mixed is the easiest place to start from." + pill primary "Start the
check".

**Active.** Eyebrow "Question N of 5" (sage-700) → progress bar (8px, `999px`, track
`--color-neutral-300`, fill `--color-accent-2-500`, `transition: width .35s ease`) → Caprasimo
question → two option buttons stacked, gap 14px: left-aligned, `--color-neutral-100` fill, 1px
`--color-neutral-400`, `--radius-md`, `padding:18px 22px`, 17px; hover fill `--color-accent-100`,
border `--color-accent-400`, `transition: background .18s ease, border-color .18s ease`.

Questions are addressed to the parent about their child (the original component asked the reader
about themselves; the buyer is the adult):

1. "When your child faces a challenging task, they usually:" — *growth:* "Get excited by the chance to learn something new" · *fixed:* "Worry about whether they'll be able to do it well"
2. "When they get feedback or criticism, they typically:" — *fixed:* "Take it personally and feel discouraged" · *growth:* "Treat it as something useful to work with"
3. "When they meet someone more skilled than they are, they tend to:" — *growth:* "Feel inspired and look for something to copy" · *fixed:* "Feel threatened or shrink away from it"
4. "After making a mistake, they usually:" — *fixed:* "Try to hide it, or explain it away" · *growth:* "Talk about it and try again"
5. "When learning something new, they believe:" — *growth:* "Ability grows with practice and effort" · *fixed:* "You're either naturally good at it or you're not"

Option order alternates deliberately so the growth answer isn't always first.

**Scoring.** `growth >= 4` → growth · `fixed >= 4` → fixed · otherwise mixed. (Unchanged from the
existing component.)

**Result.** Eyebrow "Your result" → H3 title → 18px body → a sage-800 "what to do next" line → the
email patch → an underlined "Take it again" (15px, `--color-neutral-700`) that resets to question 1.

| Result | Title | Body | Next |
|---|---|---|---|
| growth | Mostly growth mindset | "They already believe effort changes outcomes — that belief is what makes hard things survivable. The work now is protecting it when something genuinely difficult comes along." | "Use the journal's “what felt hard” prompt to keep the habit visible." |
| mixed | A mix of both | "Confident in some corners, closed in others. That is the most common result, and the most workable one — the fixed patches are usually attached to one subject or one bad memory." | "Start with the goals and affirmation prompts, and watch which subjects they avoid." |
| fixed | Leaning fixed | "Right now they read ability as something you either have or don't. That is a belief, not a personality, and it moves — usually faster than adults expect." | "Begin with the daily power-level meter. Small, visible, and hard to argue with." |

**Email patch on the result:** `--color-accent-2-200` fill, `--color-accent-2-400` border,
`--radius-lg`, `padding:26px`. "Want the free journal to work on this together?" + pill input +
pill primary "Send it to me". On success it collapses to "On its way — confirm the email we just
sent and the journal follows." Posts to the **same Kit form ID** as the other two entry points —
one list, one automation.

Per the spec, the result is shown immediately and is never held hostage behind the email form.

## Interactions & behavior

- **Navigation** — `react-router` routes; the prototype's `scrollTo({top:0})` on page change is
  what `ScrollToTop.tsx` already does.
- **Email capture** — three entry points (hero, free-guide card, quiz result), one Kit form ID, one
  list, one automation. Each keeps its own submitted flag so submitting one doesn't collapse the
  others.
- **Contact** — Formspree. Success state has a "Send another" reset; the others don't.
- **Error handling** — the spec's rules are mandatory. Success only on 2xx. Failure shows a real
  message plus a `mailto:` fallback. A missing form ID disables submit and shows a visible config
  error in dev. Never a fake success.
- **Hover** — nav labels, footer links, quiz options, and all buttons. Primary buttons take
  `--color-accent-600` on hover, `--color-accent-700` pressed (already in the system's `.btn`).
- **Focus** — `:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px; }`
  from the system. Never the browser default.
- **Motion** — one keyframe, `zrFade`: `opacity 0 → 1`, `translateY(10px) → none`, `.4s ease both`,
  applied to every success state and the quiz result. `framer-motion` is already in the project and
  can drive this instead; keep it this restrained.

## State

| State | Scope | Notes |
|---|---|---|
| `page` | Prototype only | Becomes `react-router` routing |
| `heroSent`, `guideSent`, `quizSent` | Per email form | Independent |
| `contactSent` | Contact page | Resettable via "Send another" |
| `quizStarted`, `quizIndex`, `quizAnswers[]` | Quiz | `quizAnswers.length === 5` derives the result; no separate result state |

Real submissions also need `submitting` and `error` states, which the prototype does not model —
`useFormPost` should own them.

## Configuration

The prototype exposes one toggle, `showQuizOnHome` (default on), which shows or hides the home
page's quiz section. Ship it as whatever the project prefers — a constant in `site.ts` is fine — so
the home quiz can be pulled if it doesn't earn its place.

## Assets

| File | Source | Use |
|---|---|---|
| `assets/power-up-your-mind.png` | Existing repo: `public/book-covers/en/power-up-your-mind.png` | Hero cover, home book section, Book page |
| `assets/zr-monogram.png` | Supplied by Zoe this session | Header brand mark, 30px tall. Black on transparent — **add it to the repo** (`public/images/`); it is not there yet. Also the obvious source for the favicon and the OG card the spec calls for. |
| `design-system/styles.css` | The Organic design system | Token source. Port `:root` into `tailwind.config.ts`; don't ship this file as a second stylesheet alongside Tailwind. |

Localized covers for es/fr/it/pt already exist in the repo and stay wired for when languages are
enabled. Icons, if any are added: Lucide at stroke-width 2.75, per the system.

Fonts: **Caprasimo 400** and **Figtree 400/600/700**. The spec calls for self-hosting via
`@fontsource` rather than a render-blocking Google Fonts `@import` — do that here too
(`@fontsource/caprasimo`, `@fontsource/figtree`), and remove the dead preconnect hints in
`index.html`.

## Files in this bundle

- `Zoe Roberts Site.dc.html` — the full design, all five pages, interactive. Open it in a browser
  to click through it.
- `assets/power-up-your-mind.png`, `assets/zr-monogram.png`
- `design-system/styles.css` — the Organic token sheet

## Still outstanding before launch

Unchanged from the spec's **Required Inputs** table: Zoe's portrait, real Amazon reviews, social
URLs and the X handle, the Kit form ID, the Formspree ID, her contact email, the paperback ASIN,
and the corrected journal PDF (it prints `WWW.ZOESBOOKS.NET` and has the three artwork defects).
None of these block building. Every one of them is currently omitted rather than faked.
